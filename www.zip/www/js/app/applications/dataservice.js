var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var App;
(function (App) {
    var applications;
    (function (applications) {
        var ApplicationsDataService = (function (_super) {
            __extends(ApplicationsDataService, _super);
            function ApplicationsDataService($http, $q) {
                _super.call(this, $http, $q);
                this.$http = $http;
                this.$q = $q;
            }
            ApplicationsDataService.prototype.getApplicationContent = function () {
                return this.getItemByKeyValue("OtherContent", "Id", "Applications");
            };
            ApplicationsDataService.prototype.getApplications = function () {
                return this.getItems("Applications");
            };
            return ApplicationsDataService;
        }(App.BaseJsonDataService));
        applications.ApplicationsDataService = ApplicationsDataService;
    })(applications = App.applications || (App.applications = {}));
})(App || (App = {}));
//# sourceMappingURL=dataservice.js.map
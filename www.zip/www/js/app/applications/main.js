var App;
(function (App) {
    var applications;
    (function (applications) {
        "use strict";
        angular.module('applicationsApp', [])
            .controller('applicationsController', applications.ApplicationsController)
            .service('dataService', applications.ApplicationsDataService);
    })(applications = App.applications || (App.applications = {}));
})(App || (App = {}));
//# sourceMappingURL=main.js.map
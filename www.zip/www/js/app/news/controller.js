var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var App;
(function (App) {
    var news;
    (function (news) {
        "use strict";
        var NewsController = (function (_super) {
            __extends(NewsController, _super);
            function NewsController($scope, $timeout, dataService) {
                _super.call(this, $scope, $timeout, $timeout);
                this.$scope = $scope;
                this.$timeout = $timeout;
                this.dataService = dataService;
                this.$scope.currentItem = null;
                this.$scope.news = [];
                this.$scope.newsFilters = [];
                this.$scope.months = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                this.$scope.categoryFilter = "";
                this.$scope.monthFilter = "";
                this.$scope.dateFilter = "2015-2016";
                this.$scope.searchString = "";
                this.loadNews();
                this.loadNewsOptionSet();
                this.$scope.dateFilters = [{ Name: "2015-2016", Start: 2015, End: 2016 }, { Name: "2014-2015", Start: 2014, End: 2015 }, { Name: "2013-2014", Start: 2013, End: 2014 }];
            }
            NewsController.prototype.toggleFilters = function () {
                var menu = $('.curric-facet-menu');
                menu.toggleClass('open-mobile');
            };
            NewsController.prototype.toggleSubFilter = function (divId) {
                var menu = $('#' + divId);
                var initialHeight = menu.height();
                if (initialHeight) {
                    menu.animate({ 'height': '0' }, 10);
                    return;
                }
                menu.css('height', 'auto');
                var height = menu.height();
                menu.css('height', '0');
                menu.animate({ 'height': height + 'px' }, 10);
                this.$timeout(function () {
                    menu.css('height', 'auto');
                }, 200);
            };
            NewsController.prototype.loadNewsContent = function () {
                var _this = this;
                this.dataService.getApplicationContent().then(function (data) {
                    _this.$scope.currentItem = data[0];
                });
            };
            NewsController.prototype.loadNews = function () {
                var _this = this;
                this.dataService.getNews([this.$scope.categoryFilter])
                    .then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.news, data);
                    for (var i = 0; i < _this.$scope.news.length; i++) {
                        _this.loadMetaData(_this.$scope.news[i]);
                    }
                });
            };
            NewsController.prototype.loadMetaData = function (item) {
                this.dataService.getMetadata(item.MetadataId)
                    .then(function (data) {
                    item.Metadata = data[0];
                });
            };
            NewsController.prototype.loadNewsOptionSet = function () {
                var _this = this;
                this.dataService.getNewsFilters().then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.newsFilters, data);
                });
            };
            NewsController.prototype.changeTag = function (tag) {
                this.$scope.categoryFilter = tag;
                this.loadNews();
            };
            NewsController.prototype.containsMonth = function (item) {
                if (this.$scope.monthFilter == "") {
                    return true;
                }
                return item.Metadata.CreatedOn.indexOf(this.$scope.monthFilter) > -1;
            };
            NewsController.$inject = ['$scope', '$timeout', 'dataService'];
            return NewsController;
        }(App.BaseController));
        news.NewsController = NewsController;
    })(news = App.news || (App.news = {}));
})(App || (App = {}));
//# sourceMappingURL=controller.js.map
var App;
(function (App) {
    var news;
    (function (news) {
        "use strict";
        angular.module('newsApp', [])
            .controller('newsController', news.NewsController)
            .service('dataService', news.NewsDataService).filter('highlight', function ($sce) {
            return function (text, phrase) {
                if (phrase)
                    text = text.replace(new RegExp('(' + phrase + ')', 'gi'), '<span class="highlighted">$1</span>');
                return $sce.trustAsHtml(text);
            };
        })
            .filter('fullhighlight', function ($sce) {
            return function (text, phrase) {
                if (phrase)
                    text = text.replace(new RegExp('(' + phrase + '$)', 'gi'), '<span class="highlighted">$1</span>');
                return $sce.trustAsHtml(text);
            };
        });
    })(news = App.news || (App.news = {}));
})(App || (App = {}));
//# sourceMappingURL=main.js.map
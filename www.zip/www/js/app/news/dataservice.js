var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var App;
(function (App) {
    var news;
    (function (news) {
        var NewsDataService = (function (_super) {
            __extends(NewsDataService, _super);
            function NewsDataService($http, $q) {
                _super.call(this, $http, $q);
                this.$http = $http;
                this.$q = $q;
            }
            NewsDataService.prototype.getApplicationContent = function () {
                return this.getItemByKeyValue("OtherContent", "Id", "News");
            };
            NewsDataService.prototype.getNews = function (tags) {
                return this.getItemsByTag(tags, "NewsItems");
            };
            NewsDataService.prototype.getNewsFilters = function () {
                return this.getItems("NewsFilters");
            };
            NewsDataService.prototype.getMetadata = function (Id) {
                return this.getItemByKeyValue("Metadata", "Id", Id);
            };
            return NewsDataService;
        }(App.BaseJsonDataService));
        news.NewsDataService = NewsDataService;
    })(news = App.news || (App.news = {}));
})(App || (App = {}));
//# sourceMappingURL=dataservice.js.map
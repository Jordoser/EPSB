module App {
  export class TopContent{
    public TopContent
    constructor(){
      this.TopContent = {
        //BEGIN TOP CONTENT FOR CUSTODIANS

          "TopContent1" :{
            "Name" : "Building & Systems",
            "Id" : "District Staff Resources",
            "Level" :  "2",
            "ContentId" : "Building & Systems",
            "Role" : "Custodian"
          },
          "TopContent2" :{
            "Name" : "Cleaning",
            "Id" : "Cleaning",
            "Level" :  "2",
            "ContentId" : "Cleaning",
            "Role" : "Custodian"
          },
          "TopContent3" :{
            "Name" : "Custodial & Maintenance Equipment",
            "Id" : "Custodial & Maintenance Equipment",
            "Level" :  "2",
            "ContentId" : "Custodial & Maintenance Equipment",
            "Role" : "Custodian"
          },
          "TopContent4" :{
            "Name" : "Grounds & Outside Spaces",
            "Id" : "Grounds & Outside Spaces",
            "Level" :  "2",
            "ContentId" : "Grounds & Outside Spaces",
            "Role" : "Custodian"
          },
          "TopContent5" :{
            "Name" : "Hazards & Assessments",
            "Id" : "Hazards & Assessments",
            "Level" :  "2",
            "ContentId" : "Hazards & Assessments",
            "Role" : "Custodian"
          },
          "TopContent6" :{
            "Name" : "Safe Working Conditions",
            "Id" : "Safe Working Conditions",
            "Level" :  "2",
            "ContentId" : "Safe Working Conditions",
            "Role" : "Custodian"
          },
          "TopContent7" :{
            "Name" : "Technology",
            "Id" : "Technology",
            "Level" :  "2",
            "ContentId" : "Technology",
            "Role" : "Custodian"
          },
          //END TOP CONTENT FOR CUSTODIANS

          //BEGIN TOP CONTENT FOR TEACHERS
          "TopContent8" :{
            "Name" : "Curriculum & Assessment Resources",
            "Id" : "Curriculum & Assessment Resources",
            "Level" :  "2",
            "ContentId" : "Curriculum & Assessment Resources",
            "Role" : "Teacher",
            "PageUrl" : "resourceRedirect.html"
          },
          "TopConten10" :{
            "Name" : "Inclusive Learning",
            "Id" : "Inclusive Learning",
            "Level" :  "2",
            "ContentId" : "Inclusive Learning",
            "Role" : "Teacher"
          },
          "TopContent11" :{
            "Name" : "IT Services Help Desk",
            "Id" : "IT Services Help Desk",
            "Level" :  "2",
            "ContentId" : "IT Services Help Desk",
            "Role" : "Teacher"
          },
          "TopContent12" :{
            "Name" : "Distribution Centre",
            "Id" : "Distribution Centre",
            "Level" :  "2",
            "ContentId" : "Distribution Centre",
            "Role" : "Teacher"
          },
          "TopContent13" :{
            "Name" : "Purchasing Goods & Services",
            "Id" : "Purchasing Goods & Services",
            "Level" :  "2",
            "ContentId" : "Purchasing Goods & Services",
            "Role" : "Teacher"
          }
          //END TOP CONTENT FOR TEACHERS
      }
    }
  }
}

module App {
  export class TopContent{
    public TopContent
    constructor(){
      this.TopContent = {
          "TopContent1" :{
            "Name" : "School Operations",
            "Id" : "School Operations",
            "Level" :  "1",
            "ContentId" : "School Operations",
            "Role" : "Teacher"
          },
          "TopContent2" :{
            "Name" : "District Staff Resources",
            "Id" : "District Staff Resources",
            "Level" :  "1",
            "ContentId" : "District Staff Resources",
            "Role" : "Custodian"
          },
          "TopContent3" :{
            "Name" : "Classroom & Program",
            "Id" : "Classroom & Program",
            "Level" :  "2",
            "ContentId" : "Classroom & Program",
            "Role" : "Teacher"
          },
          "TopContent4" :{
            "Name" : "Custodial & Maintenance",
            "Id" : "Custodial & Maintenance",
            "Level" :  "2",
            "ContentId" : "Custodial & Maintenance",
            "Role" : "Custodian"
          },
          "TopContent5" :{
            "Name" : "Inclusive Learning",
            "Id" : "Inclusive Learnings",
            "Level" :  "2",
            "ContentId" : "Inclusive Learning",
            "Role" : "Teacher"
          },
          "TopContent6" :{
            "Name" : "Facility Use",
            "Id" : "Facility Use",
            "Level" :  "2",
            "ContentId" : "Facility Use",
            "Role" : "Custodian"
          }
      }
    }
  }
}

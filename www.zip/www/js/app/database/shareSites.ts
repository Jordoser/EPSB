module App {
  export class ShareSites{
    public ShareSites
    constructor(){
      this.ShareSites = {
          "ShareSite1" :{
            "Name" : "Math",
            "Id" : "Math",
            "Url" : "http://www.google.ca",
          }
      }
    }
  }
}

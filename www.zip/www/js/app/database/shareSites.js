var App;
(function (App) {
    var ShareSites = (function () {
        function ShareSites() {
            this.ShareSites = {
                "ShareSite1": {
                    "Name": "Aboriginal Studies",
                    "Id": "Aboriginal Studies",
                    "Url": "http://www.google.ca",
                },
                "ShareSite2": {
                    "Name": "Career and Life Management",
                    "Id": "Career and Life Management",
                    "Url": "http://www.google.ca",
                },
                "ShareSite3": {
                    "Name": "Career and Technology Foundations / Studies",
                    "Id": "Career and Technology Foundations / Studies",
                    "Url": "http://www.google.ca",
                },
                "ShareSite4": {
                    "Name": "English as a Second Language",
                    "Id": "English as a Second Language",
                    "Url": "http://www.google.ca",
                },
                "ShareSite6": {
                    "Name": "English Language Arts ",
                    "Id": "English Language Arts ",
                    "Url": "http://www.google.ca",
                },
                "ShareSite7": {
                    "Name": "Environmental & Outdoor Education",
                    "Id": "Environmental & Outdoor Education",
                    "Url": "http://www.google.ca",
                },
                "ShareSite8": {
                    "Name": "Ethics",
                    "Id": "Ethics",
                    "Url": "http://www.google.ca",
                },
                "ShareSite9": {
                    "Name": "Fine Arts",
                    "Id": "Fine Arts ",
                    "Url": "http://www.google.ca",
                },
                "ShareSite10": {
                    "Name": "French (FSL & Francisation)",
                    "Id": "French (FSL & Francisation)",
                    "Url": "http://www.google.ca",
                },
                "ShareSite11": {
                    "Name": "Health and Life Skills",
                    "Id": "Health and Life Skills",
                    "Url": "http://www.google.ca",
                },
                "ShareSite12": {
                    "Name": "Information and Communication Technology",
                    "Id": "Information and Communication Technology",
                    "Url": "http://www.google.ca",
                },
                "ShareSite13": {
                    "Name": "International Languages",
                    "Id": "International Languages",
                    "Url": "http://www.google.ca",
                },
                "ShareSite14": {
                    "Name": "Knowledge and Employability",
                    "Id": "Knowledge and Employability",
                    "Url": "http://www.google.ca",
                },
                "ShareSite15": {
                    "Name": "Locally Developed Courses (LDCs)",
                    "Id": "Locally Developed Courses (LDCs)",
                    "Url": "http://www.google.ca",
                },
                "ShareSite16": {
                    "Name": "Mathematics",
                    "Id": "Mathematics",
                    "Url": "http://www.google.ca",
                },
                "ShareSite17": {
                    "Name": "Off-campus Education",
                    "Id": "Off-campus Education",
                    "Url": "http://www.google.ca",
                },
                "ShareSite18": {
                    "Name": "Physical Education",
                    "Id": "Physical Education",
                    "Url": "http://www.google.ca",
                },
                "ShareSite19": {
                    "Name": "Primary Grades (K–3)",
                    "Id": "Primary Grades (K–3)",
                    "Url": "http://www.google.ca",
                },
                "ShareSite20": {
                    "Name": "Science",
                    "Id": "Science",
                    "Url": "http://www.google.ca",
                },
                "ShareSite21": {
                    "Name": "Social Sciences",
                    "Id": "Social Sciences",
                    "Url": "http://www.google.ca",
                },
                "ShareSite22": {
                    "Name": "Social Studies",
                    "Id": "Social Studies",
                    "Url": "http://www.google.ca",
                },
                "ShareSite23": {
                    "Name": "Special Projects",
                    "Id": "Special Projects",
                    "Url": "http://www.google.ca",
                }
            };
        }
        return ShareSites;
    }());
    App.ShareSites = ShareSites;
})(App || (App = {}));
//# sourceMappingURL=shareSites.js.map
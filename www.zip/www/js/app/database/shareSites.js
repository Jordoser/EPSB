var App;
(function (App) {
    var ShareSites = (function () {
        function ShareSites() {
            this.ShareSites = {
                "ShareSite1": {
                    "Name": "Math",
                    "Id": "Math",
                    "Url": "http://www.google.ca",
                }
            };
        }
        return ShareSites;
    }());
    App.ShareSites = ShareSites;
})(App || (App = {}));
//# sourceMappingURL=shareSites.js.map
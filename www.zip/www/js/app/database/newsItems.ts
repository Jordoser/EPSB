module App {
  export class NewsItemDatabase{
    public NewsItems
    constructor(){
      this.NewsItems = {
        "NewsItem1" : {
          "Id" : "News1",
          "Name" : "Disctrict placed second in division for Corporate Challenge",
          "Description" : "Denote simple fat denied add worthy little use. As some he so high down am week. Conduct esteems by cottage to pasture we winding.\
           On assistance.",
          "Tags" : ["Appliances","Rental Services","School Administration","Featured"],
          "Image" : "http://gossipandgab.com/wp-content/uploads/2015/01/High-School-Teacher-and-Students-Dance-To-Uptown-Funk-500x282.jpg",
          "MetadataId": "NewsItem1"
        },
        "NewsItem2" : {
          "Id" : "News2",
          "Name" : "Aldergrove school creates new sections in their library to honour First Nations, Metis and Inuit",
          "Description" : "This is a breif description of the news item and what its all about",
          "Tags" : ["Rental Services"],
          "MetadataId": "NewsItem1"
        },
        "NewsItem3" : {
          "Id" : "News3",
          "Name" : "Aldergrove school creates new sections in their library to honour First Nations, Metis and Inuit",
          "Description" : "This is a breif description of the news item and what its all about",
          "Tags" : ["Appliances"],
          "MetadataId": "NewsItem1"
        },
        "NewsItem4" : {
          "Id" : "News4",
          "Name" : "Aldergrove school creates new sections in their library to honour First Nations, Metis and Inuit",
          "Description" : "This is a breif description of the news item and what its all about",
          "Tags" : ["Appliances"],
          "MetadataId": "NewsItem1"
        },
        "NewsItem5" : {
          "Id" : "News4",
          "Name" : "Aldergrove school creates new sections in their library to honour First Nations, Metis and Inuit",
          "Description" : "This is a breif description of the news item and what its all about",
          "Tags" : ["Appliances"],
          "MetadataId": "NewsItem1"
        },
        "NewsItem6" : {
          "Id" : "News4",
          "Name" : "Aldergrove school creates new sections in their library to honour First Nations, Metis and Inuit",
          "Description" : "This is a breif description of the news item and what its all about",
          "Tags" : ["Appliances"],
          "MetadataId": "NewsItem1"
        }
      }
    }
  }
}

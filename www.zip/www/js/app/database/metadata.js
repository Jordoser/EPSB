var App;
(function (App) {
    var MetadataDatabase = (function () {
        function MetadataDatabase() {
            this.Metadata = {
                "Metadata1": {
                    "Id": "Math 30 Assessment Metadata",
                    "CreatedBy": "Jordan Service",
                    "CreatedOn": "July 4th, 2016 "
                },
                "Metadata2": {
                    "Id": "Math 9 Classroom Resource Metadata",
                    "CreatedBy": "Jordan Service",
                    "CreatedOn": "July 4th, 2016 "
                },
                "Metadata3": {
                    "Id": "Science 20 Research & Support Metadata",
                    "CreatedBy": "Jordan Service",
                    "CreatedOn": "July 4th, 2016 "
                },
                "Metadata4": {
                    "Id": "Science 4 Assessment Metadata",
                    "CreatedBy": "Jordan Service",
                    "CreatedOn": "July 4th, 2016 "
                },
                "Metadata5": {
                    "Id": "Math and Science Grade 10 Focus on Reading Metadata Metadata",
                    "CreatedBy": "Jordan Service",
                    "CreatedOn": "July 4th, 2016 "
                },
                "Metadata6": {
                    "Id": "4th Grade Math and Science Research & Support Metadata",
                    "CreatedBy": "Jordan Service",
                    "CreatedOn": "July 4th, 2016 "
                },
                "Metadata7": {
                    "Id": "NewsItem1",
                    "CreatedBy": "Mitchell Szpytma",
                    "CreatedOn": "April 8th, 2013 "
                },
                "Metadata8": {
                    "Id": "FacilityForm.pdf Metadata",
                    "CreatedBy": "Jordan Service",
                    "CreatedOn": "July 4th, 2016 "
                },
                "Metadata9": {
                    "Id": "FacilityManual.doc Metadata",
                    "CreatedBy": "Jordan Service",
                    "CreatedOn": "May 2nd, 2016 "
                },
                "Metadata10": {
                    "Id": "FacilityHazardousForm.pdf Metadata",
                    "CreatedBy": "Jordan Service",
                    "CreatedOn": "June 9th, 2016 "
                },
                "Metadata11": {
                    "Id": "EquippmentAndElectronicManual.docx Metadata",
                    "CreatedBy": "Jordan Service",
                    "CreatedOn": "Sept 10th, 2016 "
                },
                "Metadata12": {
                    "Id": "FacilityPolicies.doc Metadata",
                    "CreatedBy": "Mitchell Szpytma",
                    "CreatedOn": "April 8th, 2013 "
                }
            };
        }
        return MetadataDatabase;
    }());
    App.MetadataDatabase = MetadataDatabase;
})(App || (App = {}));
//# sourceMappingURL=metadata.js.map
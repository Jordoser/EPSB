var App;
(function (App) {
    var ApplicationsDatabase = (function () {
        function ApplicationsDatabase() {
            this.Applications = {
                "Application1": {
                    "Id": "G-Mail",
                    "Name": "G-Mail",
                    "Description": "",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                },
                "Application2": {
                    "Id": "Google Calendar",
                    "Name": "Google Calendar",
                    "Description": "",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                },
                "Application3": {
                    "Id": "Google Drive",
                    "Name": "Google Drive",
                    "Description": "Create online documents and spreadsheets. Share and collaborate.",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                },
                "Application4": {
                    "Id": "PeopleSoft Self Service",
                    "Name": "Google",
                    "Description": "Your personal pay & benefits information.",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                },
                "Application5": {
                    "Id": "Remote Desktop",
                    "Name": "Remote Desktop",
                    "Description": "Sign in to access your files from home.",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                },
                "Application6": {
                    "Id": "E-Biz",
                    "Name": "E-Biz",
                    "Description": "Expense claims.",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                },
                "Application7": {
                    "Id": "Orbit",
                    "Name": "Orbit",
                    "Description": "Online IT requests.",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                },
                "Application8": {
                    "Id": "Pinpoint Student",
                    "Name": "Pinpoint Student",
                    "Description": "Student records.",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                },
                "Application9": {
                    "Id": "Power School",
                    "Name": "Power School",
                    "Description": "Application description.",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                },
                "Application10": {
                    "Id": "Power Teachers",
                    "Name": "Power Teachers",
                    "Description": "Application description.",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                },
                "Application11": {
                    "Id": "SchoolZone",
                    "Name": "SchoolZone",
                    "Description": "School and student information.",
                    "Favorite": "true",
                    "Tags": ["Teacher"]
                }
            };
        }
        return ApplicationsDatabase;
    }());
    App.ApplicationsDatabase = ApplicationsDatabase;
})(App || (App = {}));
//# sourceMappingURL=applications.js.map
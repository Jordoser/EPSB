var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var App;
(function (App) {
    var curriculum;
    (function (curriculum) {
        var CurriculumDataService = (function (_super) {
            __extends(CurriculumDataService, _super);
            function CurriculumDataService($http, $q) {
                _super.call(this, $http, $q);
                this.$http = $http;
                this.$q = $q;
            }
            CurriculumDataService.prototype.getApplicationContent = function () {
                return this.getItemByKeyValue("OtherContent", "Id", "Curriculum");
            };
            CurriculumDataService.prototype.getCurriculum = function (tags) {
                return this.getItemsByTag(tags, "CurriculumItems");
            };
            CurriculumDataService.prototype.getCurriculumFilters = function () {
                return this.getItems("CurriculumFilters");
            };
            CurriculumDataService.prototype.getMetadata = function (Id) {
                return this.getItemByKeyValue("Metadata", "Id", Id);
            };
            return CurriculumDataService;
        }(App.BaseJsonDataService));
        curriculum.CurriculumDataService = CurriculumDataService;
    })(curriculum = App.curriculum || (App.curriculum = {}));
})(App || (App = {}));
//# sourceMappingURL=dataservice.js.map
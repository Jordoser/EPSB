var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var App;
(function (App) {
    var curriculum;
    (function (curriculum_1) {
        "use strict";
        var CurriculumController = (function (_super) {
            __extends(CurriculumController, _super);
            function CurriculumController($scope, $timeout, dataService) {
                _super.call(this, $scope, $timeout, $timeout);
                this.$scope = $scope;
                this.$timeout = $timeout;
                this.dataService = dataService;
                this.$scope.maxSubjects = 6;
                this.$scope.maxContent = 8;
                this.$scope.gradeTags = [];
                this.$scope.subjectTags = [];
                this.$scope.curriculumTags = [];
                this.$scope.curriculumTypeTags = [];
                this.$scope.contentTypeTags = [];
                this.$scope.gradeAndSubjectArray = [];
                this.$scope.curriculumArray = [];
                this.$scope.shareSites = [];
                this.$scope.selectedShareSite = "";
                this.$scope.gradeFilter = '';
                this.$scope.subjectFilter = '';
                this.$scope.resourceFilter = '';
                this.$scope.contentTypeFilter = '';
                this.$scope.curriculumTypeFilter = '';
                this.$scope.curriculumFilter = '';
                this.$scope.currentItem;
                this.loadDistrictContent();
                this.loadShareSites();
                this.loadGradeTags();
                this.loadSubjectTags();
                this.loadCurriculumTags();
                this.loadCurriculumTypeTags();
                this.loadContentTypeTags();
                this.loadGradeAndSubjectResource();
                this.loadGradeAndSubjectResource(true);
                var filterSet = JSON.parse(localStorage.getItem("FilterAndSet"));
                switch (filterSet.SetNumber) {
                    case 1:
                        this.changeGradeTag(filterSet.Filter);
                        break;
                    case 2:
                        this.changeSubjectTag(filterSet.Filter);
                        break;
                    case 3:
                        $('a[href="#profile"]').trigger('click');
                        this.changeCurriculumTag(filterSet.Filter, true);
                        break;
                    default:
                        break;
                }
            }
            CurriculumController.prototype.toggleFilters = function (menuId) {
                var menu = $('#' + menuId);
                menu.toggleClass('open-mobile');
            };
            CurriculumController.prototype.toggleSubFilter = function (parentDivId, divId) {
                var menu = $("#" + parentDivId + " #" + divId);
                var initialHeight = menu.height();
                if (initialHeight) {
                    menu.animate({ 'height': '0' }, 10);
                    return;
                }
                menu.css('height', 'auto');
                var height = menu.height();
                menu.css('height', '0');
                menu.animate({ 'height': height + 'px' }, 10);
                this.$timeout(function () {
                    menu.css('height', 'auto');
                }, 200);
            };
            CurriculumController.prototype.openSite = function () {
                window.open('EPSShareSite/home.html', '_blank');
            };
            CurriculumController.prototype.loadShareSites = function () {
                var _this = this;
                this.dataService.getShareSites()
                    .then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.shareSites, data);
                    _this.$scope.selectedShareSite = "";
                });
            };
            CurriculumController.prototype.loadDistrictContent = function () {
                var _this = this;
                this.dataService.getDistrictContent()
                    .then(function (data) {
                    _this.$scope.currentItem = data[0];
                });
            };
            CurriculumController.prototype.loadGradeTags = function () {
                var _this = this;
                this.dataService.getGradeTags()
                    .then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.gradeTags, data);
                });
            };
            CurriculumController.prototype.loadSubjectTags = function () {
                var _this = this;
                this.dataService.getSubjectTags()
                    .then(function (data) {
                    data = _.sortBy(data, function (o) { return (o.Core != 'true'); });
                    App.Common.replaceArrayContents(_this.$scope.subjectTags, data);
                });
            };
            CurriculumController.prototype.loadCurriculumTags = function () {
                var _this = this;
                this.dataService.getCurriculumTags()
                    .then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.curriculumTags, data);
                });
            };
            CurriculumController.prototype.loadCurriculumTypeTags = function () {
                var _this = this;
                this.dataService.getCurriculumTypeTags()
                    .then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.curriculumTypeTags, data);
                });
            };
            CurriculumController.prototype.loadContentTypeTags = function () {
                var _this = this;
                this.dataService.getContentTags()
                    .then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.contentTypeTags, data);
                });
            };
            CurriculumController.prototype.loadGradeAndSubjectResource = function (isCurric) {
                var _this = this;
                if (isCurric === void 0) { isCurric = false; }
                this.dataService.getGradeAndSubject([this.$scope.gradeFilter, this.$scope.subjectFilter, this.$scope.resourceFilter, this.$scope.contentTypeFilter, this.$scope.curriculumFilter, this.$scope.curriculumTypeFilter])
                    .then(function (data) {
                    if (isCurric) {
                        App.Common.replaceArrayContents(_this.$scope.curriculumArray, data);
                        return;
                    }
                    App.Common.replaceArrayContents(_this.$scope.gradeAndSubjectArray, data);
                });
            };
            CurriculumController.prototype.changeGradeTag = function (tag, curriculum) {
                if (curriculum === void 0) { curriculum = false; }
                this.$scope.gradeFilter = tag;
                this.loadGradeAndSubjectResource(curriculum);
            };
            CurriculumController.prototype.changeSubjectTag = function (tag, curriculum) {
                if (curriculum === void 0) { curriculum = false; }
                this.$scope.subjectFilter = tag;
                this.loadGradeAndSubjectResource(curriculum);
            };
            CurriculumController.prototype.changeContentTag = function (tag, curriculum) {
                if (curriculum === void 0) { curriculum = false; }
                this.$scope.contentTypeFilter = tag;
                this.loadGradeAndSubjectResource(curriculum);
            };
            CurriculumController.prototype.changeCurriculumTypeTag = function (tag, curriculum) {
                if (curriculum === void 0) { curriculum = false; }
                this.$scope.curriculumTypeFilter = tag;
                this.loadGradeAndSubjectResource(curriculum);
            };
            CurriculumController.prototype.changeCurriculumTag = function (tag, curriculum) {
                if (curriculum === void 0) { curriculum = false; }
                this.$scope.curriculumFilter = tag;
                this.loadGradeAndSubjectResource(curriculum);
            };
            CurriculumController.prototype.clearFilters = function () {
                this.$scope.curriculumFilter = "";
                this.$scope.gradeFilter = "";
                this.$scope.subjectFilter = "";
                this.$scope.contentTypeFilter = "";
                this.$scope.curriculumFilter = "";
                this.$scope.curriculumTypeFilter = "";
                this.loadGradeAndSubjectResource();
                this.loadGradeAndSubjectResource(true);
            };
            CurriculumController.$inject = ['$scope', '$timeout', 'dataService'];
            return CurriculumController;
        }(App.BaseController));
        curriculum_1.CurriculumController = CurriculumController;
    })(curriculum = App.curriculum || (App.curriculum = {}));
})(App || (App = {}));
//# sourceMappingURL=controller.js.map
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var App;
(function (App) {
    var curriculumIndex;
    (function (curriculumIndex) {
        "use strict";
        var CurriculumIndexController = (function (_super) {
            __extends(CurriculumIndexController, _super);
            function CurriculumIndexController($scope, $timeout, dataService) {
                _super.call(this, $scope, $timeout, $timeout);
                this.$scope = $scope;
                this.$timeout = $timeout;
                this.dataService = dataService;
                this.$scope.gradeTags = [];
                this.$scope.subjectTags = [];
                this.$scope.curriculumTags = [];
                this.loadGradeTags();
                this.loadSubjectTags();
                this.loadCurriculumTags();
            }
            CurriculumIndexController.prototype.loadGradeTags = function () {
                var _this = this;
                this.dataService.getGradeTags()
                    .then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.gradeTags, data);
                });
            };
            CurriculumIndexController.prototype.loadSubjectTags = function () {
                var _this = this;
                this.dataService.getSubjectTags()
                    .then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.subjectTags, data);
                });
            };
            CurriculumIndexController.prototype.loadCurriculumTags = function () {
                var _this = this;
                this.dataService.getCurriculumTags()
                    .then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.curriculumTags, data);
                });
            };
            CurriculumIndexController.prototype.redirect = function (filter, setNumber) {
                var filterSet = { Filter: filter, SetNumber: setNumber };
                var filterSetString = JSON.stringify(filterSet);
                localStorage.setItem("FilterAndSet", filterSetString);
                window.location.href = "curriculumnAndAssesment";
            };
            CurriculumIndexController.$inject = ['$scope', '$timeout', 'dataService'];
            return CurriculumIndexController;
        }(App.BaseController));
        curriculumIndex.CurriculumIndexController = CurriculumIndexController;
    })(curriculumIndex = App.curriculumIndex || (App.curriculumIndex = {}));
})(App || (App = {}));
//# sourceMappingURL=controller.js.map
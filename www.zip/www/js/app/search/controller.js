var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var App;
(function (App) {
    var search;
    (function (search) {
        "use strict";
        var SearchController = (function (_super) {
            __extends(SearchController, _super);
            function SearchController($scope, $timeout, dataService, $q) {
                _super.call(this, $scope, $timeout, $timeout);
                this.$scope = $scope;
                this.$timeout = $timeout;
                this.dataService = dataService;
                this.$q = $q;
                this.$scope.currentItem = null;
                this.$scope.searchString = sessionStorage.getItem("SearchString");
                this.$scope.searchResults = [];
                this.$scope.tags = [];
                this.$scope.typeArray = [];
                this.searchAll(this.$scope.searchString);
                this.loadTypeFilters();
            }
            SearchController.prototype.loadTypeFilters = function () {
                var _this = this;
                this.dataService.getTypeFilters()
                    .then(function (data) {
                    App.Common.replaceArrayContents(_this.$scope.typeArray, data);
                });
            };
            SearchController.prototype.isTypeFilter = function (tag) {
                return (_.filter(this.$scope.typeArray, function (type) {
                    return type.Tag == tag;
                }).length > 0);
            };
            SearchController.prototype.searchReset = function (searchstring) {
                this.$scope.searchString = searchstring;
                this.searchAll(searchstring);
            };
            SearchController.prototype.searchAll = function (searchString) {
                var _this = this;
                this.$scope.tags.length = 0;
                this.$scope.searchResults.length = 0;
                var promises = {
                    documents: this.searchDocuments(searchString),
                    apps: this.searchApps(searchString),
                    l2: this.searchL2(searchString),
                    l3: this.searchL3(searchString),
                    l4: this.searchL4(searchString)
                };
                var tags = [];
                this.$q.all(promises).then(function (values) {
                    for (var i = 0; i < values["documents"].length; i++) {
                        _this.$scope.searchResults.push(values["documents"][i]);
                        tags = _.concat(tags, values["documents"][i].Tags);
                    }
                    for (var i = 0; i < values["apps"].length; i++) {
                        _this.$scope.searchResults.push(values["apps"][i]);
                        tags = _.concat(tags, values["apps"][i].Tags);
                    }
                    for (var i = 0; i < values["l2"].length; i++) {
                        values["l2"][i].Tags = [values["l2"][i].Id];
                        _this.$scope.searchResults.push(values["l2"][i]);
                        tags = _.concat(tags, values["l2"][i].Tags);
                    }
                    for (var i = 0; i < values["l3"].length; i++) {
                        values["l3"][i].Tags = [values["l3"][i].Id];
                        _this.$scope.searchResults.push(values["l3"][i]);
                        tags = _.concat(tags, values["l3"][i].Tags);
                    }
                    for (var i = 0; i < values["l4"].length; i++) {
                        values["l4"][i].Tags = [values["l4"][i].Id];
                        _this.$scope.searchResults.push(values["l4"][i]);
                        tags = _.concat(tags, values["l4"][i].Tags);
                    }
                    _this.$scope.totalResults = _this.$scope.searchResults.length;
                    if (_this.$scope.searchResults.length > 15) {
                        _this.$scope.searchResults.length = 15;
                    }
                    var uniqTags = _.uniq(tags);
                    tags = _.map(uniqTags, function (tag) {
                        var length = _.reject(tags, function (e) {
                            return (e.indexOf(tag) < 0);
                        }).length;
                        return { tag: tag, count: length };
                    });
                    App.Common.replaceArrayContents(_this.$scope.tags, tags);
                });
            };
            SearchController.prototype.searchApps = function (searchString) {
                var deferred = this.$q.defer();
                this.dataService.getApps()
                    .then(function (data) {
                    data = _.filter(data, function (o) {
                        return (o.Name.includes(searchString) ||
                            o.Description.includes(searchString) ||
                            (o.Tags.indexOf(searchString) > -1));
                    });
                    deferred.resolve(data);
                })
                    .catch(function (ex) {
                    deferred.reject();
                });
                return deferred.promise;
            };
            SearchController.prototype.searchDocuments = function (searchString) {
                var deferred = this.$q.defer();
                this.dataService.getDocuments()
                    .then(function (data) {
                    data = _.filter(data, function (o) {
                        return (o.Name.includes(searchString) ||
                            o.Description.includes(searchString) ||
                            (o.Tags.indexOf(searchString) > -1));
                    });
                    deferred.resolve(data);
                })
                    .catch(function (ex) {
                    deferred.reject();
                });
                return deferred.promise;
            };
            SearchController.prototype.searchL2 = function (searchString) {
                var deferred = this.$q.defer();
                this.dataService.getL2Items()
                    .then(function (data) {
                    data = _.filter(data, function (o) {
                        o.Description = (o.Description) ? o.Description : "";
                        return (o.Name.includes(searchString) ||
                            o.Description.includes(searchString));
                    });
                    deferred.resolve(data);
                })
                    .catch(function (ex) {
                    deferred.reject();
                });
                return deferred.promise;
            };
            SearchController.prototype.searchL3 = function (searchString) {
                var deferred = this.$q.defer();
                this.dataService.getL3Items()
                    .then(function (data) {
                    data = _.filter(data, function (o) {
                        o.Description = (o.Description) ? o.Description : "";
                        return (o.Name.includes(searchString) ||
                            o.Description.includes(searchString));
                    });
                    deferred.resolve(data);
                })
                    .catch(function (ex) {
                    deferred.reject();
                });
                return deferred.promise;
            };
            SearchController.prototype.searchL4 = function (searchString) {
                var deferred = this.$q.defer();
                this.dataService.getL4Items()
                    .then(function (data) {
                    data = _.filter(data, function (o) {
                        o.Description = (o.Description) ? o.Description : "";
                        return (o.Name.includes(searchString) ||
                            o.Description.includes(searchString));
                    });
                    deferred.resolve(data);
                })
                    .catch(function (ex) {
                    deferred.reject();
                });
                return deferred.promise;
            };
            SearchController.$inject = ['$scope', '$timeout', 'dataService', '$q'];
            return SearchController;
        }(App.BaseController));
        search.SearchController = SearchController;
    })(search = App.search || (App.search = {}));
})(App || (App = {}));
//# sourceMappingURL=controller.js.map
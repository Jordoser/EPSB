module App {
  export class MetadataDatabase{
    public Metadata;
    constructor(){
      this.Metadata = {
        "Metadata1" : {
          "Id":"Math 30 Assessment Metadata",
          "CreatedBy": "Jordan Service",
          "CreatedOn": "July 4, 2016 "
        },
        "Metadata2" : {
          "Id":"Math 9 Classroom Resource Metadata",
          "CreatedBy": "Jordan Service",
          "CreatedOn": "July 4, 2016 "
        },
        "Metadata3" : {
          "Id":"Science 20 Research & Support Metadata",
          "CreatedBy": "Jordan Service",
          "CreatedOn": "July 4, 2016 "
        },
        "Metadata4" : {
          "Id":"Science 4 Assessment Metadata",
          "CreatedBy": "Jordan Service",
          "CreatedOn": "July 4, 2016 "
        },
        "Metadata5" : {
          "Id":"Math and Science Grade 10 Focus on Reading Metadata Metadata",
          "CreatedBy": "Jordan Service",
          "CreatedOn": "July 4, 2016 "
        },
        "Metadata6" : {
          "Id":"4th Grade Math and Science Research & Support Metadata",
          "CreatedBy": "Jordan Service",
          "CreatedOn": "July 4, 2016 "
        },
        "Metadata7" : {
          "Id": "NewsItem1",
          "CreatedBy": "Mitchell Szpytma",
          "CreatedOn": "August 3, 2016 "
        },
        "Metadata8" : {
          "Id":"FacilityForm.pdf Metadata",
          "CreatedBy": "Jordan Service",
          "CreatedOn": "July 4, 2016 "
        },
        "Metadata9" : {
          "Id":"NoBullyingYouLoser.pdf Metadata",
          "CreatedBy": "Jordan Service",
          "CreatedOn": "May 2, 2016 "
        },
        "Metadata10" : {
          "Id":"FacilityHazardousForm.pdf Metadata",
          "CreatedBy": "Jordan Service",
          "CreatedOn": "June 9, 2016 "
        },
        "Metadata11" : {
          "Id":"EquippmentAndElectronicManual.docx Metadata",
          "CreatedBy": "Jordan Service",
          "CreatedOn": "Sept 10, 2016 "
        },
        "Metadata12" : {
          "Id": "FacilityPolicies.doc Metadata",
          "CreatedBy": "Mitchell Szpytma",
          "CreatedOn": "April 8, 2013 "
        },
        "Metadat13" : {
          "Id": "NewsItem2",
          "CreatedBy": "Mitchell Szpytma",
          "CreatedOn": "August 3, 2016 "
        },
        "Metadat14" : {
          "Id": "NewsItem3",
          "CreatedBy": "Mitchell Szpytma",
          "CreatedOn": "July 22, 2016 "
        },
        "Metadat15" : {
          "Id": "NewsItem4",
          "CreatedBy": "Mitchell Szpytma",
          "CreatedOn": "June 22, 2016 "
        }
      }
    }
  }
}

var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var App;
(function (App) {
    var curriculumIndex;
    (function (curriculumIndex) {
        var CurriculumIndexDataService = (function (_super) {
            __extends(CurriculumIndexDataService, _super);
            function CurriculumIndexDataService($http, $q) {
                _super.call(this, $http, $q);
                this.$http = $http;
                this.$q = $q;
            }
            CurriculumIndexDataService.prototype.getApplicationContent = function () {
                return this.getItemByKeyValue("OtherContent", "Id", "CurriculumIndex");
            };
            CurriculumIndexDataService.prototype.getGradeTags = function () {
                return this.getItems("GradeFilters");
            };
            CurriculumIndexDataService.prototype.getSubjectTags = function () {
                return this.getItems("SubjectFilters");
            };
            CurriculumIndexDataService.prototype.getCurriculumTags = function () {
                return this.getItems("CurriculumSubjectFilters");
            };
            return CurriculumIndexDataService;
        }(App.BaseJsonDataService));
        curriculumIndex.CurriculumIndexDataService = CurriculumIndexDataService;
    })(curriculumIndex = App.curriculumIndex || (App.curriculumIndex = {}));
})(App || (App = {}));
//# sourceMappingURL=dataservice.js.map
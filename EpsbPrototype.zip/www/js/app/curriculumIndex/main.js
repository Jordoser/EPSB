var App;
(function (App) {
    var curriculumIndex;
    (function (curriculumIndex) {
        "use strict";
        angular.module('curriculumIndexApp', [])
            .controller('curriculumIndexController', curriculumIndex.CurriculumIndexController)
            .service('dataService', curriculumIndex.CurriculumIndexDataService);
    })(curriculumIndex = App.curriculumIndex || (App.curriculumIndex = {}));
})(App || (App = {}));
//# sourceMappingURL=main.js.map
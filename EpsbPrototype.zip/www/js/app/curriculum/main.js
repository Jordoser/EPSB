var App;
(function (App) {
    var curriculum;
    (function (curriculum) {
        "use strict";
        angular.module('curriculumApp', [])
            .controller('curriculumController', curriculum.CurriculumController)
            .service('dataService', curriculum.CurriculumDataService).filter('highlight', function ($sce) {
            return function (text, phrase) {
                if (phrase)
                    text = text.replace(new RegExp('(' + phrase + ')', 'gi'), '<span class="highlighted">$1</span>');
                return $sce.trustAsHtml(text);
            };
        })
            .filter('fullhighlight', function ($sce) {
            return function (text, phrase) {
                if (phrase)
                    text = text.replace(new RegExp('(' + phrase + '$)', 'gi'), '<span class="highlighted">$1</span>');
                return $sce.trustAsHtml(text);
            };
        });
    })(curriculum = App.curriculum || (App.curriculum = {}));
})(App || (App = {}));
//# sourceMappingURL=main.js.map
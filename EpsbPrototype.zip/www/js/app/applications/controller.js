var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var App;
(function (App) {
    var applications;
    (function (applications) {
        "use strict";
        var ApplicationsController = (function (_super) {
            __extends(ApplicationsController, _super);
            function ApplicationsController($scope, $timeout, dataService) {
                _super.call(this, $scope, $timeout, $timeout);
                this.$scope = $scope;
                this.$timeout = $timeout;
                this.dataService = dataService;
                this.$scope.currentItem = null;
                this.$scope.applications = [];
                this.loadApplicationsContent();
                this.loadApplications();
            }
            ApplicationsController.prototype.loadApplicationsContent = function () {
                var _this = this;
                this.dataService.getApplicationContent().then(function (data) {
                    _this.$scope.currentItem = data[0];
                });
            };
            ApplicationsController.prototype.loadApplications = function () {
                var _this = this;
                this.dataService.getApplications()
                    .then(function (data) {
                    data = _.sortBy(data, function (o) { return (o.Favorite == 'false'); });
                    App.Common.replaceArrayContents(_this.$scope.applications, data);
                });
            };
            ApplicationsController.$inject = ['$scope', '$timeout', 'dataService'];
            return ApplicationsController;
        }(App.BaseController));
        applications.ApplicationsController = ApplicationsController;
    })(applications = App.applications || (App.applications = {}));
})(App || (App = {}));
//# sourceMappingURL=controller.js.map
var App;
(function (App) {
    var search;
    (function (search) {
        "use strict";
        angular.module('searchApp', [])
            .controller('searchController', search.SearchController)
            .service('dataService', search.SearchDataService)
            .filter('highlight', function ($sce) {
            return function (text, phrase) {
                if (phrase)
                    text = text.replace(new RegExp('(' + phrase + ')', 'gi'), '<span class="highlighted">$1</span>');
                return $sce.trustAsHtml(text);
            };
        })
            .filter('fullhighlight', function ($sce) {
            return function (text, phrase) {
                if (phrase)
                    text = text.replace(new RegExp('(' + phrase + '$)', 'gi'), '<span class="highlighted">$1</span>');
                return $sce.trustAsHtml(text);
            };
        });
    })(search = App.search || (App.search = {}));
})(App || (App = {}));
//# sourceMappingURL=main.js.map
var App;
(function (App) {
    var UsersDatabase = (function () {
        function UsersDatabase() {
        }
        return UsersDatabase;
    }());
    App.UsersDatabase = UsersDatabase;
})(App || (App = {}));
//# sourceMappingURL=users.js.map
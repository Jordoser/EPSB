module App {
  export class UsersDatabase{
    public Users
    constructor(){
    }
  }
}

var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var App;
(function (App) {
    var curriculum;
    (function (curriculum) {
        var CurriculumDataService = (function (_super) {
            __extends(CurriculumDataService, _super);
            function CurriculumDataService($http, $q) {
                _super.call(this, $http, $q);
                this.$http = $http;
                this.$q = $q;
            }
            CurriculumDataService.prototype.getGradeTags = function () {
                return this.getItems("GradeFilters");
            };
            CurriculumDataService.prototype.getSubjectTags = function () {
                return this.getItems("SubjectFilters");
            };
            CurriculumDataService.prototype.getCurriculumTags = function () {
                return this.getItems("CurriculumSubjectFilters");
            };
            CurriculumDataService.prototype.getCurriculumTypeTags = function () {
                return this.getItems("ResourceTypeFilters");
            };
            CurriculumDataService.prototype.getGradeAndSubject = function (Tags) {
                return this.getItemsByTag(Tags, "Resources");
            };
            CurriculumDataService.prototype.getContentTags = function () {
                return this.getItems("DocumentTypeFilters");
            };
            return CurriculumDataService;
        }(App.BaseJsonDataService));
        curriculum.CurriculumDataService = CurriculumDataService;
    })(curriculum = App.curriculum || (App.curriculum = {}));
})(App || (App = {}));
//# sourceMappingURL=dataservice.js.map